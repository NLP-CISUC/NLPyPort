from NLPyPort.FullPipeline import *
from LemPyPort.LemFunctions import *
from NLPyPort.LemPyPort.dictionary import *
from NLPyPort.TokPyPort.Tokenizer import *
from NLPyPort.TagPyPort.Tagger import *
from NLPyPort.CRF.CRF_Teste import *
from NLPyPort.text import *